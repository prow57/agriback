export class GetAdviceDto {
      cropOrAnimalType: string;
        farmingMethods: string;
          issuesOrChallenges: string;
         
        }


