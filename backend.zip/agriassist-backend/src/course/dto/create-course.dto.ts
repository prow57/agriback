export class CreateCourseDto {
      category: string;
        title: string;
          description: string;
          }

